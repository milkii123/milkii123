      <footer class="main-footer">
        <div class="float-right d-none d-sm-block"><b>Version</b> 2.0.0</div>
        <strong>Copyright &copy; 2021-2022 <a href="#">Pharmacy.com</a>.</strong> All rights reserved.
      </footer>